const dotenv = require("dotenv");
const path = require("path");
const express = require("express");
const bodyParser = require("body-parser");
const session = require("express-session");
const multer = require("multer");

dotenv.config();

const app = express({ path: "./.env" });

const fileStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "images");
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  },
});
const fileFilter = (req, file, cb) => {
  if (
    file.mimetype === "image/png" ||
    file.mimetype === "image/jpg" ||
    file.mimetype === "image/jpeg"
  ) {
    cb(null, true);
  } else {
    cb(null, false);
  }
};

app.set("view engine", "ejs");
app.set("views", "views");

const marketRoutes = require("./routes/shop");
const loginRoutes = require("./routes/userAccounts");
const adminPanelRoutes = require("./routes/adminPanel");

app.use(
  bodyParser.urlencoded({
    extended: true,
  })
);
app.use(
  session({
    secret: "session_cookie_secret",
    resave: false,
    saveUninitialized: true,
    cookie: {
      maxAge: 864000000,
    },
  })
);
app.use(bodyParser.urlencoded({ extended: false }));
app.use(
  multer({ storage: fileStorage, fileFilter: fileFilter }).single("image")
);
app.use(express.static(path.join(__dirname, "public")));
app.use(express.static(path.join(__dirname, "assets")));
app.use(express.static(path.join(__dirname, "public")));
app.use("/images", express.static(path.join(__dirname, "images")));
app.use(marketRoutes);
app.use(loginRoutes);
app.use(adminPanelRoutes);

let port = process.env.PORT || 3000;
app.listen(port, () => console.log(`NodeJS is running on port ${port}!`));
