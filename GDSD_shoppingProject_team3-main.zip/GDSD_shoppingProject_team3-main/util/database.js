const mysql = require("mysql2");
require("dotenv").config({ path: "./.env" });
const pool = mysql.createPool({
  host: "localhost",
  user: "root",
  database: "node_complete",
  password: "",
});

// const pool = mysql.createPool({
//   host: "database-2.cpslqr44gyke.us-east-1.rds.amazonaws.com",
//   user: "hiteshtest",
//   database: "node_complete",
//   password: "hiteshtest",
//   insecureAuth: true,
// });

// const pool = mysql.createPool({
//   host: process.env.DATABASE_HOST,
//   user: process.env.DATABASE_USER,
//   database: process.env.DATABASE,
//   password: process.env.DATABASE_PASSWORD,
//   insecureAuth: true,
// });

module.exports = pool.promise();
