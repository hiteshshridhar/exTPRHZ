const db = require("../util/database");
const bcrypt = require('bcryptjs')

module.exports = class userAccounts {
  constructor(username, email, password) {
    this.username = username;
    this.email = email;
    this.password = password;
  }

  checkEmail() {
    return db.query("select * from adminaccounts where email=?", [this.email]);
  }

  static login(email) {
    return db.query("SELECT * FROM adminaccounts WHERE email = ? ", [email]);
  }

  async register() {
    let hashedPass = await bcrypt.hash(this.password, 8);
    return db.execute(
      "INSERT INTO adminaccounts (username, email, password) VALUES (?, ?, ?)",
      [this.username, this.email, hashedPass]
    );
  }

};
