const db = require("../util/database");
const bcrypt = require("bcryptjs");

module.exports = class userAccounts {
  constructor(username, email, password) {
    this.username = username;
    this.email = email;
    this.password = password;
  }

  checkEmail() {
    return db.query("select * from accounts where email=?", [this.email]);
  }

  async register() {
    let hashedPass = await bcrypt.hash(this.password, 8);
    return db.execute(
      "INSERT INTO accounts (username, email, password) VALUES (?, ?, ?)",
      [this.username, this.email, hashedPass]
    );
  }

  static login(email) {
    return db.query("SELECT * FROM accounts WHERE email = ? ", [email]);
  }

  static getCredits(username) {
    return db.query("SELECT points, name from accounts where username = ? ", [
      [username],
    ]);
  }

  static getUserAds(username) {
    return db.query("SELECT * from products where seller = ? ", [[username]]);
  }
};
