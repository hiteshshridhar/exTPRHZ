//We are using EJS(Embedded Javascript template), a templating language used for generating simple HTML markup with plain Javascript.
// We are also using ES6 in our project. It is the 6th edition of ECMAScript. (a way of javascript)
// We are using express, as it is a web framework that let's you structure a web application to handle multiple
//different http requests at a specific url.
const db = require("../util/database");
const moment = require("moment");
// We use module.exports and exports in Javascript, as to use OOP(i.e. Object Oriented Programming.)
module.exports = class Product {
  constructor(
    title,
    description,
    image,
    price,
    posted_on,
    category,
    postcode,
    city,
    street,
    sellerName,
    contact,
    seller
  ) {
    this.title = title;
    this.description = description;
    this.image = image;
    this.price = price;
    this.posted_on = posted_on;
    this.category = category;
    this.postcode = postcode;
    this.city = city;
    this.street = street;
    this.sellerName = sellerName;
    this.contact = contact,
    this.seller = seller;
  }

  save() {
    return db.execute(
      "INSERT INTO products (title, description, imageUrl, price, posted_on, category, postcode, city, street, sellerName, contact, seller) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
      [
        this.title,
        this.description,
        this.image,
        this.price,
        this.posted_on,
        this.category,
        this.postcode,
        this.city,
        this.street,
        this.sellerName,
        this.contact,
        this.seller
      ]
    );
  }
  
  
  
  static update(
    adId,
    title,
    description,
    image,
    price,
    posted_on,
    category,
    postcode,
    city,
    street,
    contact) {

      console.log(
        adId,
        title,
        description,
        image,
        price,
        posted_on,
        category,
        postcode,
        city,
        street,
        contact)


    return db.execute(
      ` UPDATE products SET title=?, description=?, imageUrl=?, price=?, posted_on=?, category=?, postcode=?, city =?, street =?, contact =? WHERE id=${adId} `,
      [
        title,
        description,
        image,
        price,
        posted_on,
        category,
        postcode,
        city,
        street,
        contact
      ]
    
    );
  }


  //static(keyword) is used as we are not going to change the value 
  //AND is used for multiple condititons
  //${} is a expression to show the dynamic value integration
  //The line inside of % is a condition %
  // The return value will go into the function and will be used where the function has been called

  static findByTitle(title, category, minPrice, maxPrice, city) {
    if (minPrice == "" || minPrice == null) {
      return db.execute(
        `SELECT * FROM products
         WHERE approve_status='approved'
         AND title LIKE '%${title}%'
         AND ('${category}' = '' OR category = '${category}')
         AND ('${city}' = '' OR city = '${city}')
         AND price <= ${maxPrice}
         `
      );
    } else if (maxPrice == "" || maxPrice == null) {
      return db.execute(
        `SELECT * FROM products
         WHERE approve_status='approved'
         AND title LIKE '%${title}%'
         AND ('${category}' = '' OR category = '${category}')
         AND ('${city}' = '' OR city = '${city}')
         AND price >= ${minPrice}
         `
      );
    } else {
      return db.execute(
        `SELECT * FROM products
        WHERE approve_status='approved'
        AND title LIKE '%${title}%'
        AND ('${category}' = '' OR category = '${category}')
        AND ('${city}' = '' OR city = '${city}')
        AND price BETWEEN ${minPrice} AND ${maxPrice}
       `
      );
    }
  }

  //The id we get from the method calling it, example in
  static findById(id) {
    return db.execute("SELECT * FROM products WHERE products.id=?", [id]);
  }

  static fetchAll() {
    return db.execute("SELECT * FROM products");
  }

  static fetchAllApproved() {
    return db.execute("SELECT * FROM products WHERE approve_status='approved'");
  }
  static fetchAllRejected() {
    return db.execute("SELECT * FROM products WHERE approve_status='rejected'");
  }

  static fetchAllPending() {
    return db.execute("SELECT * FROM products WHERE approve_status='pending'");
  }

  static approvePost(id) {
    return db.execute(
      `UPDATE products SET approve_status = 'approved' WHERE id = '${id}'`
    );
  }
  static rejectPost(id) {
    return db.execute(
      `UPDATE products SET approve_status = 'rejected' WHERE id = '${id}'`
    );
  }
};
