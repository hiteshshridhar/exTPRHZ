//import UserAccounts
const userAccounts = require("../models/userAccounts");
//import bcrypt library
const bcrypt = require("bcryptjs");

/*
Function to check wether the user is logged in or not. Also used for redirecting already logged in
users to the browse page if they try to access localhost:3000/login
*/
exports.login = (req, res, next) => {
  //display current login status in console for development purposes
  // console.log(req.session.isLoggedIn);
  //Check if the session variable is true or false
  if (req.session.isLoggedIn == true) {
    //if the variable is true, then go to browse page
    res.redirect("/browse");
  } else {
    //if the session variable is false, then go to login page
    res.render("shop/login", {
      path: "/login",
      message: "",
    });
  }
};

//Function to logout from the website
exports.logout = (req, res, next) => {
  //display current login status in console for development purposes
  // console.log(req.session.isLoggedIn);
  //Set the session variable to false
  req.session.isLoggedIn = false;
  //Go back to the landing page
  res.redirect("/");
};

//Function to serve the Register page
exports.getRegister = (req, res, next) => {
  //Render the register.ejs page in views/shop
  res.render("shop/register", {
    path: "/register",
    error: ``,
  });
};

//Function to render the ForgotPassword page
exports.forgotPassword = (req, res, next) => {
  //Render the forgotPassword.ejs page in views/shop
  res.render("shop/forgotPassword", {
    path: "/forgotPassword",
    message: "",
  });
};

/*
Function to register a new user on the website. Also check if an account with the same email already
exists or not
*/
exports.postRegisterUser = (req, res, next) => {
  //Get username, email and password from the client
  const username = req.body.username;
  const email = req.body.email;
  const password = req.body.password;
  //Create a new userAccounts object
  const registeraccount = new userAccounts(username, email, password);
  //Call the checkEmail function in userAccounts class
  registeraccount
    .checkEmail(email)
    //After getting the response, doo the following:
    .then((response) => {
      /*
      If response is not empty/undefined and the email in the response is same as request, then
      display a message on the register.ejs page saying "An account with this email already exists"
      */
      if (response[0][0] != undefined && response[0][0].email == email) {
        // if (!response[0]) {
        res.render("shop/register", {
          //Pass the error text to the page via the error variable
          error: `An account with this email already exists`,
        });
      }
      //If the condition above is not fulfilled, then call the register function and redirect to login page
      else {
        registeraccount.register().then(() => {
          res.redirect("/login");
        });
      }
    })
    //If there are any errors, display them in the console
    .catch((err) => console.log(err));
};

//Function to Login to the website
exports.getAuth = async (request, response, next) => {
  // console.log(request.get("Cookie").split(";")[2]);
  //Get username and poassword from client
  const username = request.body.email;
  const password = request.body.password;
  //Try - Catch
  //Try Block
  try {
    //Call the login function in userAccounts class and pass username and password to that function
    userAccounts
      .login(username, password)
      //Do the following after getting a reponse:
      .then(([results]) => {
        // console.log(results[0]);
        /*
        Use the bcrpyt library to compare the password in the database and the password we got above
        in the password variable. Bcrypt will hash the password we got in the variable above and compare
        it to the password we got in the response
        */
        bcrypt
          .compare(password, results[0].password)
          //when the password comparison is complete, do the following:
          .then((result) => {
            /*
            If the result of bcrypt comparison is true, then set the session variable to true
            and set the username to the one that was fetched above by the login function.
            Finally, redirect to the browse page
            */
            if (result) {
              // console.log("authentication successful");
              request.session.isLoggedIn = true;
              request.session.username = results[0].username;
              response.redirect("/browse");
            } else {
              /*
            If bcrypt comparison returns false, then set the session variable to false and display a
            message on the login.ejs page saying "Email or Password incorrect"
             */
              request.session.isLoggedIn = false;
              console.log("authentication failed. Password doesn't match");
              response.render("shop/login", {
                path: "/login",
                loginerror: "Email or Password incorrect",
              });
            }
          })
          //If there are any errors, display them in the console
          .catch((err) => console.error(err));
      })
      .catch((err) => console.log(err));
  } catch (err) {
    console.log(err);
  }
};
