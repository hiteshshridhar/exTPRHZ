const Product = require("../models/products");
const moment = require("moment");


exports.getBrowse = (req, res, next) => {

  if (req.session.adminLogin == true){
    Product.fetchAllPending()
    .then(([rows]) => {
      res.render("admin/index", {
        prods: rows,
        path: "/admin",
        page_name: "pending",
      });
    })
    .catch(err => console.log(err));
    }
  else {
     // res.render("admin/adminLogin", {
      //  path: "/adminLogin",
       // message: "",
      //});
      res.redirect('/adminLogin')
    }
};

exports.getApproved = (req, res, next) => {
  if (req.session.adminLogin == true)
    Product.fetchAllApproved()
      .then(([rows, fieldData]) => {
        res.render("admin/index", {
          prods: rows,
          path: "/admin",
          page_name: "approve",
        });
      })
      .catch(err => console.log(err));
  else {
        res.render("admin/adminLogin", {
          path: "/adminlogin",
          message: "",
        });
        }
    };
exports.getRejected = (req, res, next) => {
  if (req.session.adminLogin == true)
    Product.fetchAllRejected()
      .then(([rows, fieldData]) => {
        res.render("admin/index", {
          prods: rows,
          path: "/admin",
          page_name: "rejected",
        });
      })
      .catch(err => console.log(err));
  else {
      res.render("admin/adminLogin", {
        path: "/adminlogin",
        message: "",
      });
    }
};
exports.getAllposts = (req, res, next) => {
  if (req.session.adminLogin == true)
    Product.fetchAll()
      .then(([rows, fieldData]) => {
        res.render("admin/index", {
          prods: rows,
          path: "/admin",
          page_name: "allposts",
        });
      })
      .catch(err => console.log(err));
  else {
    res.render("admin/adminLogin", {
      path: "/adminlogin",
      message: "",
        });
  }
};

exports.postApprove = async (req, res, next) => {
  const id = req.params.id;
  console.log(req.originalUrl.split("/")[1]);
  var gotoUrl = req.originalUrl.split("/")[1];
  await Product.approvePost(id).then(() => {
    res.redirect(`/${gotoUrl}`);
  });
};
exports.postReject = (req, res, next) => {
  const id = req.params.id;
  var gotoUrl = req.originalUrl.split("/")[1];

  console.log(req.originalUrl.split("/")[1]);
  Product.rejectPost(id).then(() => {
    res.redirect(`/${gotoUrl}`);
  });
};

/*
exports.editProductDetails = (req, res, next) => {
  const id = req.params.id;
  if (req.session.isLoggedIn == true)  
    Product.findById(id)
      .then(([product]) => {
        res.render("shop/editUserHistoryAd", {
          product: product[0],
          path: "/editUserHistoryAd",
          login: req.session.isLoggedIn,
          username: req.session.username,
        });
      })
      .catch((err) => console.log(err));
  else {
      res.redirect("/login");
    }
};
*/

exports.postEditProduct = (req, res, next) => {
  const id = req.params.id;
  Product.findById(id)
    .then(product => {
      console.log(product);
      product.approve_status = "approved";
      Product.save();
    })
    .then(result => console.log("Product Approved"))
    .catch(err => console.log(err));
};
