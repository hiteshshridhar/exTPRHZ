const Product = require("../models/products");
const accounts = require("../models/userAccounts");
const moment = require("moment");

exports.postAddProduct = (req, res, next) => {
  const title = req.body.title;
  const description = req.body.description;
  const imageUrl = req.file;
  const image = imageUrl.path;
  const price = req.body.price;
  const posted_on = moment(new Date()).format("DD/MM/YYYY");
  const category = req.body.category;
  const postcode = req.body.plz;
  const city = req.body.city;
  const street = req.body.streetNr;
  const sellerName = req.body.name;
  const contact = req.body.phone;
  const seller = req.session.username;
  const product = new Product(
    title,
    description,
    image,
    price,
    posted_on,
    category,
    postcode,
    city,
    street,
    sellerName,
    contact,
    seller
  );
  product
    .save()
    .then(() => {
      res.redirect("/browse");
    })
    .catch((err) => console.log(err));
};

var adId = null

exports.updateAd =async (req, res, next) => {
  const title = req.body.title;
  const description = req.body.description;
  const imageUrl = req.file;
  const image = imageUrl.path;
  const price = req.body.price;
  const posted_on = moment(new Date()).format("DD/MM/YYYY");
  const category = req.body.category;
  const postcode = req.body.plz;
  const city = req.body.city;
  const street = req.body.streetNr;
  const contact = req.body.phone;
  console.log(adId)
  await Product.update(
    adId,
    title,
    description,
    image,
    price,
    posted_on,
    category,
    postcode,
    city,
    street,
    contact)
    res.redirect("/userProfile");
};





exports.getProducts = (req, res, next) => {
  Product.fetchAllApproved((products) => {
    res.render("/productList", {
      product: products,
      path: "/products",
    });
  }).catch((err) => console.log(err));
};
exports.userProfile = async (req, res, next) => {
  const userData = await accounts
    .getCredits(req.session.username)
    .then(([result]) => {
    
      const data = {
        points: result[0].points,
        name: result[0].name,
      };
      return data;
    })
    .catch((err) => console.log(err));
    
  const prods = await accounts
    .getUserAds(req.session.username)
    .then(([products]) => {
      return products;
    })
    .catch((err) => console.log(err));
  

  res.render("shop/profile", {
    path: "/userProfile",
    login: req.session.isLoggedIn,
    username: req.session.username,
    credits: userData.points,
    name: userData.name,
    prods: prods,
  });
};
exports.forgotPassword = (req, res, next) => {
  res.render("shop/forgetPassword", {
    path: "/forgotPassword",
  });
};
exports.claimRewards = (req, res, next) => {
  Product.fetchAllApproved("")
    .then(([rows, fieldData]) => {
      res.render("shop/claimRewards", {
        prods: rows,
        path: "/claimRewards",
        login: req.session.isLoggedIn,
        username: req.session.username,
      });
    })
    .catch((err) => console.log(err));
};

exports.editAd = (req, res, next) => {
  Product.fetchAllApproved("")
    .then(([rows, fieldData]) => {
      res.render("shop/editAd", {
        prods: rows,
        path: "/editAd",
        login: req.session.isLoggedIn,
        username: req.session.username,
      });
    })
    .catch((err) => console.log(err));
};

exports.activeAds = (req, res, next) => {
  res.render("shop/historyUser", {
    path: "/activeAds",
    login: req.session.isLoggedIn,
    username: req.session.username,
    page_name: "activeAds",
  });
};

exports.inactiveAds = (req, res, next) => {
  Product.fetchAllApproved("")
    .then(([rows, fieldData]) => {
      res.render("shop/historyUser", {
        prods: rows,
        path: "/inactiveAds",
        login: req.session.isLoggedIn,
        username: req.session.username,
        page_name: "inactiveAds",
      });
    })
    .catch((err) => console.log(err));
};

exports.recentPurchases = (req, res, next) => {
  res.render("shop/recentPurchases", {
    path: "/recentPurchases",
    login: req.session.isLoggedIn,
    username: req.session.username,
  });
};

exports.pendingAds = (req, res, next) => {
  Product.fetchAllApproved("")
    .then(([rows, fieldData]) => {
      res.render("shop/historyUser", {
        prods: rows,
        path: "/pendingAds",
        login: req.session.isLoggedIn,
        username: req.session.username,
        page_name: "pendingAds",
      });
    })
    .catch((err) => console.log(err));
};

exports.historyUser = (req, res, next) => {
  Product.fetchAllApproved("")
    .then(([rows, fieldData]) => {
      res.render("shop/historyUser", {
        prods: rows,
        path: "/historyUser",
        login: req.session.isLoggedIn,
        username: req.session.username,
        page_name: "historyUser",
      });
    })
    .catch((err) => console.log(err));
};

exports.getIndex = (req, res, next) => {
  res.render("shop/index", {
    path: "/",
    login: req.session.isLoggedIn,
    username: req.session.username,
  });
};
exports.addProduct_page = (req, res, next) => {
  if (req.session.isLoggedIn == true)
    res.render("shop/addProduct", {
      path: "/startSelling",
      login: req.session.isLoggedIn,
      username: req.session.username,
    });
  else {
    res.redirect("/login");
  }
};
exports.productDetails = (req, res, next) => {
  const id = req.params.id;
  Product.findById(id)
    .then(([product]) => {
      res.render("shop/productDetails", {
        product: product[0],
        path: "/productDetails",
        login: req.session.isLoggedIn,
        username: req.session.username,
      });
    })
    .catch((err) => console.log(err));
};

exports.editProductDetails = (req, res, next) => {
   adId = req.params.id;
  if (req.session.isLoggedIn == true)  
    Product.findById(adId)
      .then(([product]) => {
        res.render("shop/editUserHistoryAd", {
          product: product[0],
          path: "/editUserHistoryAd",
          login: req.session.isLoggedIn,
          username: req.session.username,
        });
      })
      .catch((err) => console.log(err));
  else {
      res.redirect("/login");
    }
};



exports.getBrowse = (req, res, next) => {
  // This will fetch all the approved products by the admin, from models->products.js
  if (req.session.isLoggedIn == true)
  Product.fetchAllApproved()
    .then(([rows, fieldData]) => {
      res.render("shop/browse", {
        prods: rows,
        path: "/browse",
        login: req.session.isLoggedIn,
        username: req.session.username,
      });
    })
    .catch((err) => console.log(err));
    else {
      res.redirect("/login");
    } 
};

exports.getProductsByKeyword = (req, res, next) => {
  const prodTitle = req.query.title;
  const category = req.query.category;
  const minPrice = req.query.minPrice;
  const maxPrice = req.query.maxPrice;
  const city = req.query.city;
  Product.findByTitle(prodTitle, category, minPrice, maxPrice, city)
    .then(([rows]) => {
      res.render("shop/browse", {
        prods: rows,
        path: "/browse/search",
        login: req.session.isLoggedIn,
        username: req.session.username,
      });
    })
    .catch((err) => console.log(err));
};
