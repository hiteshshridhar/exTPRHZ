# GDSD - Online Shopping Project (Team-3)
This is a collaborative Master's Project under the guidance of Prof. Dr. Todtenhoefer from university of Applied Sciences Fulda. We have created a website with modern functionality like Chat. User can only register with the Hochschule Fulda email address. User can view, select and upload products in order to sell or buy them.  

The Team consists of the following members: 

Hitesh Shridhar (Team Lead)
hitesh.shridhar@informatik.hs-fulda.de, honey7sharma@gmail.com (Github E-Mail), hiteshshridhar(Github username)

Mohsin Kamal Akbar (Back-end Team Lead)
mohsin.kamal.akbar@informatik.hs-fulda.de, mohsin.kamal.akbar@gmail.com (Github email), RoddyGlitch (Githun username)

Parul Soni (Front-end Team Lead)
parul.soni@informatik.hs-fulda.de (Github email), 97parul(GitHub username)

Kamal Chhirang : kamal.chhirang@informatik.hs-fulda.de, kamal5chhirang@gmail.com (Github email), KamalChhirang (Github username)

Fiaz : fiaz.ashraf@informatik.hs-fulda.de, Fiazashraf73@gmail.com(Github email), fiazashraf(Github username)

Shazeem : shazeem.ashar@informatik.hs-fulda.de, shazeem9@gmail.com(Github email), ShazeemAshar(Github username)
