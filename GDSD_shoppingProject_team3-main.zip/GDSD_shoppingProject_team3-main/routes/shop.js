const express = require("express");
const shopController = require("../controllers/shopController");
const router = express.Router();

router.get("/", shopController.getIndex);
router.get("/browse/search", shopController.getProductsByKeyword);
router.get("/browse", shopController.getBrowse);
router.post("/add-product", shopController.postAddProduct);
router.get("/productDetails/:id", shopController.productDetails);
router.get("/startSelling", shopController.addProduct_page);
router.get("/userProfile", shopController.userProfile);
router.get("/forgotPassword", shopController.forgotPassword);
router.get("/claimRewards", shopController.claimRewards);
router.get("/historyUser", shopController.historyUser);
router.get("/pendingAds", shopController.pendingAds);
router.get("/editAd", shopController.editAd);
router.get("/activeAds", shopController.activeAds);
router.get("/inactiveAds", shopController.inactiveAds);
router.get("/recentPurchases", shopController.recentPurchases);
router.get("/editUserHistoryAd/:id", shopController.editProductDetails);
router.post("/updateAd/", shopController.updateAd);

module.exports = router;
