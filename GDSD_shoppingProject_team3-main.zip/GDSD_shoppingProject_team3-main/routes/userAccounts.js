const express = require("express");
const userAccounts = require("../controllers/userAccounts");
const shopController = require("../controllers/shopController");

const router = express.Router();

router.get("/login", userAccounts.login);
router.get("/logout", userAccounts.logout);
router.get("/register", userAccounts.getRegister);
router.post("/registerUser", userAccounts.postRegisterUser);
router.post("/auth", userAccounts.getAuth);
router.get("/browse", shopController.getBrowse);

module.exports = router;
