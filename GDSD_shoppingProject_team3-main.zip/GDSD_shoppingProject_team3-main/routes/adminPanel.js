const express = require("express");
const userController = require("../controllers/admin");

const adminController = require("../controllers/adminAccounts");
const router = express.Router();

router.get("/admin", userController.getBrowse);
router.get("/approve", userController.getApproved);
router.get("/reject", userController.getRejected);
router.get("/allposts", userController.getAllposts);
router.get("/approve/:id", userController.postApprove);
router.get("/reject/:id", userController.postReject);
router.get("/adminRegister", adminController.getRegister);
router.post("/registerAdminUser", adminController.postRegister);
router.get("/adminlogin", adminController.login);
router.post("/adminloginAuth", adminController.getAuth);
router.get("/adminlogout", adminController.logout);


module.exports = router;
